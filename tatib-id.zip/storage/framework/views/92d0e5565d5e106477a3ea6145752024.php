

<?php $__env->startSection('title', 'Input Pelanggaran - SITATIB'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Input Pelanggaran</h1>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5><i class="fas fa-plus me-2"></i>Tambah Pelanggaran Baru</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('violations.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <div class="mb-3">
                            <label for="nama" class="form-label">Nama Siswa *</label>
                            
                            <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama"
                                name="nama" value="<?php echo e(old('nama')); ?>" required>
                            <div class="form-text">Ketik nama siswa untuk mencari otomatis.</div>
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="kelas" class="form-label">Kelas *</label>
                            
                            <input type="text" class="form-control <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kelas"
                                name="kelas" value="<?php echo e(old('kelas')); ?>" required>
                            <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label for="pelanggaran" class="form-label">Jenis Pelanggaran *</label>
                            <select class="form-select <?php $__errorArgs = ['pelanggaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pelanggaran"
                                name="pelanggaran" required>
                                <option value="">Pilih Pelanggaran</option>
                                <option value="Terlambat">Terlambat</option>
                                <option value="Tidak memakai seragam lengkap">Tidak memakai seragam lengkap</option>
                                <option value="Tidak membawa buku">Tidak membawa buku</option>
                                <option value="Tidak mengerjakan tugas">Tidak mengerjakan tugas</option>
                                <option value="Berbicara tidak sopan">Berbicara tidak sopan</option>
                                <option value="Merokok">Merokok</option>
                                <option value="Membawa HP saat pelajaran">Membawa HP saat pelajaran</option>
                                <option value="Keluar kelas tanpa izin">Keluar kelas tanpa izin</option>
                                <option value="Lainnya">Lainnya</option>
                            </select>
                            <?php $__errorArgs = ['pelanggaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3" id="custom-violation" style="display: none;">
                            <label for="custom_pelanggaran" class="form-label">Tuliskan Pelanggaran Lainnya</label>
                            <input type="text" class="form-control" id="custom_pelanggaran" name="custom_pelanggaran">
                        </div>
                        <div class="mb-3">
                            <label for="point" class="form-label">Point Pelanggaran *</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['point'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="point"
                                name="point" value="<?php echo e(old('point')); ?>" min="1" required>
                            <?php $__errorArgs = ['point'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label for="tanggal_waktu" class="form-label">Tanggal & Waktu Kejadian *</label>
                            <input type="datetime-local" class="form-control <?php $__errorArgs = ['tanggal_waktu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="tanggal_waktu" name="tanggal_waktu"
                                value="<?php echo e(old('tanggal_waktu', now()->format('Y-m-d\TH:i'))); ?>" required>
                            <div class="form-text">Nilai default adalah waktu sekarang, tapi bisa diubah sesuai waktu
                                kejadian.</div>
                            <?php $__errorArgs = ['tanggal_waktu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Simpan Pelanggaran
                        </button>
                    </form>
                </div>
            </div>
        </div>

        
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h6><i class="fas fa-info-circle me-2"></i>Panduan Point</h6>
                </div>
                <div class="card-body">
                    <small>
                        <strong>Ringan (1-10 point):</strong><br>• Terlambat: 5 point<br>• Tidak membawa buku: 3
                        point<br><br>
                        <strong>Sedang (11-25 point):</strong><br>• Tidak mengerjakan tugas: 15 point<br>• Tidak berseragam
                        lengkap: 20 point<br><br>
                        <strong>Berat (26-50 point):</strong><br>• Berbicara tidak sopan: 30 point<br>• Keluar kelas tanpa
                        izin: 25 point<br><br>
                        <strong>Sangat Berat (51-100 point):</strong><br>• Merokok: 75 point<br>• Membawa HP saat pelajaran:
                        50 point
                    </small>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    
    
    <script>
        $(function() {
            // Script untuk Autocomplete Nama Siswa
            $("#nama").autocomplete({
                source: "<?php echo e(route('students.search')); ?>",
                minLength: 2,
                select: function(event, ui) {
                    $('#nama').val(ui.item.value);
                    $('#kelas').val(ui.item.kelas);
                    return false;
                }
            });

            // Script untuk Autofill Point dan menampilkan input 'Lainnya'
            $('#pelanggaran').on('change', function() {
                const selectedViolation = $(this).val();

                if (selectedViolation === 'Lainnya') {
                    $('#custom-violation').slideDown();
                    $('#custom_pelanggaran').attr('required', true);
                    $('#point').val('').focus();
                } else {
                    $('#custom-violation').slideUp();
                    $('#custom_pelanggaran').removeAttr('required');
                }

                const pointMap = {
                    'Terlambat': 5,
                    'Tidak membawa buku': 3,
                    'Tidak mengerjakan tugas': 15,
                    'Tidak memakai seragam lengkap': 20,
                    'Berbicara tidak sopan': 30,
                    'Keluar kelas tanpa izin': 25,
                    'Membawa HP saat pelajaran': 50,
                    'Merokok': 75
                };

                if (pointMap[selectedViolation]) {
                    $('#point').val(pointMap[selectedViolation]);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\tatib-id\resources\views/violations/create.blade.php ENDPATH**/ ?>