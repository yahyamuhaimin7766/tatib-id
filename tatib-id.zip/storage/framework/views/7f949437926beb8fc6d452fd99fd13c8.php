

<?php $__env->startSection('title', 'Dashboard - SITATIB'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Dashboard</h1>
        <div class="text-muted"><?php echo e(now()->format('d F Y')); ?></div>
    </div>

    
    
    
    <div class="row">

        
        <div class="col-lg-8 mb-4">
            <div class="card h-100">
                <div class="card-header">
                    <h5><i class="fas fa-chart-bar me-2"></i>Point Pelanggaran Per Kelas</h5>
                </div>
                <div class="card-body d-flex align-items-center">
                    <canvas id="classPointsChart"></canvas>
                </div>
            </div>
        </div>

        
        <div class="col-lg-4 mb-4">
            
            <div class="card text-white bg-danger mb-3">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h6 class="card-title mb-1">Total Pelanggaran</h6>
                            <h3 class="card-text fw-bold"><?php echo e($totalViolations); ?></h3>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-exclamation-triangle fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="card text-white bg-warning mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h6 class="card-title mb-1">Siswa Terlambat</h6>
                            <h3 class="card-text fw-bold"><?php echo e($totalLateArrivals); ?></h3>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clock fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="card">
                <div class="card-header">
                    <h5><i class="fas fa-trophy me-2"></i>Kelas Paling Disiplin</h5>
                </div>
                <div class="card-body p-2" style="max-height: 250px; overflow-y: auto;">
                    <ul class="list-group list-group-flush">
                        <?php $__empty_1 = true; $__currentLoopData = $cleanestClasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <strong><?php echo e($loop->iteration); ?>. <?php echo e($class->kelas); ?></strong>
                                <span
                                    class="badge <?php echo e($class->total_violations == 0 ? 'bg-success' : 'bg-warning text-dark'); ?> rounded-pill">
                                    <?php echo e($class->total_violations); ?> Pelanggaran
                                </span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="list-group-item text-center">Belum ada data untuk di-ranking.</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Baris 2: Tabel Bawah (Razia & Ranking Siswa) -->
    <div class="row">
        <div class="col-lg-5 mb-4">
            <div class="card h-100">
                <div class="card-header">
                    <h5><i class="fas fa-search me-2"></i>Hasil Razia Terbaru</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Nama Siswa</th>
                                <th>Kelas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $recentRaids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $raid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(\Carbon\Carbon::parse($raid->tanggal_waktu)->format('d/m/y')); ?></td>
                                    <td><?php echo e(Str::limit($raid->nama_siswa, 15)); ?></td>
                                    <td><?php echo e($raid->kelas); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center p-3">Belum ada data razia terbaru.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer text-center">
                    <a href="<?php echo e(route('raids.index')); ?>" class="btn btn-sm btn-outline-primary">Lihat Semua Data Razia</a>
                </div>
            </div>
        </div>
        <div class="col-lg-7 mb-4">
            <div class="card h-100">
                <div class="card-header">
                    <h5><i class="fas fa-list-ol me-2"></i>Ranking Siswa Sering Melanggar</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>Nama Siswa</th>
                                <th>Kelas</th>
                                <th>Total Point</th>
                                <th>Jumlah Pelanggaran</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $frequentViolators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($student->nama); ?></td>
                                    <td><?php echo e($student->kelas); ?></td>
                                    <td><span class="badge bg-danger"><?php echo e($student->total_point); ?></span></td>
                                    <td class="text-center"><?php echo e($student->violations_count); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center p-3">Belum ada data pelanggaran siswa.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        // Chart untuk Point Pelanggaran Per Kelas
        const classPointsCtx = document.getElementById('classPointsChart').getContext('2d');
        const classPointsData = <?php echo json_encode($classPoints, 15, 512) ?>;
        const classPointsChart = new Chart(classPointsCtx, {
            type: 'bar',
            data: {
                labels: classPointsData.map(item => item.kelas),
                datasets: [{
                    label: 'Total Point',
                    data: classPointsData.map(item => item.total_points),
                    backgroundColor: 'rgba(220, 53, 69, 0.7)',
                    borderColor: 'rgba(220, 53, 69, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\tatib-id\resources\views/home.blade.php ENDPATH**/ ?>