

<?php $__env->startSection('title', 'Razia - SITATIB'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Rekap Hasil Razia</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <a href="<?php echo e(route('raids.create')); ?>" class="btn btn-sm btn-primary">
                <i class="fas fa-plus me-2"></i>Input Data Baru
            </a>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('raids.index')); ?>" method="GET" class="row g-3 align-items-center">
                <div class="col-auto"><label for="kelas" class="form-label mb-0 fw-bold">Filter Kelas:</label></div>
                <div class="col-auto">
                    <select name="kelas" id="kelas" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="all">Tampilkan Semua Kelas</option>
                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($class->kelas); ?>" <?php echo e(request('kelas') == $class->kelas ? 'selected' : ''); ?>>
                                <?php echo e($class->kelas); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </form>
        </div>
    </div>

    
    <form action="<?php echo e(route('raids.bulk.destroy')); ?>" method="POST" id="bulk-delete-form-raids"
        onsubmit="return confirm('Apakah Anda yakin ingin menghapus semua data razia yang dipilih?');">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5><i class="fas fa-list-ul me-2"></i>Data Tercatat</h5>
                <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash me-2"></i>Hapus yang
                    Dipilih</button>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th class="text-center" style="width: 1%;"><input type="checkbox" id="select-all"></th>
                                <th style="width: 5%;">No</th>
                                <th>Tanggal & Waktu</th>
                                <th>Nama Siswa</th>
                                <th>Kelas</th>
                                <th>Foto Barang</th>
                                <th>Penanggung Jawab</th>
                                <th style="width: 15%;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $raids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $raid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center"><input type="checkbox" name="ids[]"
                                            value="<?php echo e($raid->id); ?>" class="item-checkbox"></td>
                                    <td><?php echo e($raids->firstItem() + $index); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($raid->tanggal_waktu)->format('d M Y, H:i')); ?></td>
                                    <td><?php echo e($raid->nama_siswa); ?></td>
                                    <td><?php echo e($raid->kelas); ?></td>
                                    <td>
                                        <?php if($raid->foto_barang): ?>
                                            <a href="<?php echo e(asset('storage/' . $raid->foto_barang)); ?>" target="_blank">
                                                <img src="<?php echo e(asset('storage/' . $raid->foto_barang)); ?>" alt="Foto Barang"
                                                    width="100">
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($raid->penanggung_jawab); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('raids.show', $raid->id)); ?>" class="btn btn-sm btn-info"
                                            title="Detail"><i class="fas fa-eye"></i></a>
                                        <a href="<?php echo e(route('raids.edit', $raid->id)); ?>" class="btn btn-sm btn-warning"
                                            title="Edit"><i class="fas fa-edit"></i></a>
                                        <button type="submit" form="delete-form-raid-<?php echo e($raid->id); ?>"
                                            class="btn btn-sm btn-danger" title="Hapus"><i
                                                class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center p-4">Tidak ada data hasil razia untuk filter ini.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php if($raids->hasPages()): ?>
                <div class="card-footer"><?php echo e($raids->links()); ?></div>
            <?php endif; ?>
        </div>
    </form>

    
    <?php $__currentLoopData = $raids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $raid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('raids.destroy', $raid->id)); ?>" method="POST" id="delete-form-raid-<?php echo e($raid->id); ?>"
            class="d-none" onsubmit="return confirm('Yakin hapus data ini?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.getElementById('select-all').addEventListener('click', function(event) {
            document.querySelectorAll('.item-checkbox').forEach(checkbox => {
                checkbox.checked = event.target.checked;
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\tatib-id\resources\views/raids/index.blade.php ENDPATH**/ ?>